/*-------------------------------------------------------------------------*
 *---									---*
 *---		whaleWatchers.cpp					---*
 *---									---*
 *---	    This file implements a program that simulates the harpooners---*
 *---	of the Pequod giving up whaling for guiding Customer instances	---*
 *---	on whale-watching cruises.  Each boat has a linked-list of	---*
 *---	Customer instances.  Each boat, and the dock, is run with its	---*
 *---	own thread, where only one Customer instance may move at a time.---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1a					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

//
//	Compile with:
//	$ g++ whaleWatchers.cpp -o whaleWatchers -lpthread
//

#include	<stdlib.h>
#include	<stdio.h>
#include	<unistd.h>	// For sleep()
#include	<pthread.h>


//  PURPOSE:  To tell the names of the whale-watching boat skippers.
const char*	SKIPPER_NAME_CPTR_ARRAY[]
					= {"Queequeg",
					   "Tashtego",
					   "Daggoo",
					   "Fedallah"
					  };

const int	NUM_BOATS		= sizeof(SKIPPER_NAME_CPTR_ARRAY) /
      					  sizeof(const char*);


//  PURPOSE:  To tell the names of the Customer instances.
const char*	CUSTOMER_NAME_CPTR_ARRAY[]
					= {"Anne",
					   "Alice",
					   "Antoinette",
					   "Bob",
					   "Brian",
					   "Brandon",
					   "Carol",
					   "Cathy",
					   "Cleopatra",
					   "David",
					   "Danny",
					   "Douglass"
					  };

const int	NUM_CUSTOMERS		= sizeof(CUSTOMER_NAME_CPTR_ARRAY) /
      					  sizeof(const char*);

const int	NUM_CUSTOMERS_PER_BOAT	= NUM_CUSTOMERS / NUM_BOATS;


//  PURPOSE:  To represent a Customer as a node in a list.
class		Customer
{
  //  I.  Member vars:
  //  PURPOSE:  To point to the next node in the list.
  Customer*			nextPtr_;

  //  PURPOSE:  To point to the C-string holding the name.
  const char*			nameCPtr_;

  //  II.  Disallowed auto-generated methods:
  //  No default constructor:
  Customer			();

  //  No copy assignment op:
  Customer&	operator=	(const Customer&);

protected :
  //  III.  Protected methods:

public :
  //  IV.  Constructor(s), assignment op(s), factory(s) and destructor:
  //  PURPOSE:  To initialize '*this' to be a node with name 'newNamePtr'.
  //	No return value.
  Customer			(const char*	newNamePtr
				) :
				nextPtr_(NULL),
				nameCPtr_(newNamePtr)
				{ }

  //  PURPOSE:  To release the resources of '*this'.  No parameters.
  //	No return values.
  ~Customer			()
				{ }

  //  V.  Accessors:
  //  PURPOSE:  To return the address of the next node in the list.
  //	No parameters.
  Customer*	getNextPtr	()
				const
				{ return(nextPtr_); }

  //  PURPOSE:  To return the C-string holding the name.  No parameters.
  const char*	getNameCPtr	()
				const
				{ return(nameCPtr_); }

  //  VI.  Mutators:
  //  PURPOSE:  To set the address of the next node in the list to 'ptr'.
  //	No return value.
  void		setNextPtr	(Customer*		ptr
				)
				{ nextPtr_	= ptr; }

  //  VII.  Methods that do main and misc. work of class:
  //  PURPOSE:  To say a departing message.  No parameters.  No return
  //  	value.
  void		printDepartingMsg
				()
				const
  {
    printf("  %s \"",getNameCPtr());

    switch  (rand() % 8)
    {
    case 0 :
      printf("I'm glad I went!  I got good pictures.");
      break;
    case 1 :
      printf("I'm glad to be back on land!  I'm sea-sick.");
      break;
    case 2 :
      printf("That mama-whale had perfect pitch!  "
	     "She just sang 5 octaves below what I'm used to."
	    );
      break;
    case 3 :
      printf("How delightful!  "
	     "The dolphins were sopranos and the hump-backs were bass!"
	    );
      break;
    case 4 :
      printf("With a bishop and 2 knights she trounced me!  I'm out $%d",
	     100+50*(rand()%4)
	    );
      break;
    case 5 :
      printf("A clever response to my Sicilian defense!"
	     "  That blue whale earned that $%d",100+50*(rand()%4)
	    );
      break;
    case 6 :
      printf("Hey Mr. Whale, you want my money?  "
	     "Get my wallet from the bottom of the sea!"
	    );
      break;
   case 7 :
      printf("It's difficult to harmonize when "
	     "your partner sings 4 octaves below you."
	    );
      break;
    }
    printf("\"\n");
  }


};


//  PURPOSE:  To represent a Boat as (among other things) a linked-list of
//  	Customer instances.
class		Boat
{
  //  I.  Member vars:
  //  DECLARE YOUR MEMBER VARS HERE
  Customer*first;
  Customer*least;
  int listlength;

  //  PURPOSE:  To point to the C-string telling the name.
  const char*			nameCPtr_;

  //  PURPOSE:  To hodl the address of the Customer who either may board or
  //	may step over to the next boat.
  Customer*			preBoarderPtr_;

  //  II.  Disallowed auto-generated methods:
  //  No default constructor:
  Boat				();

  //  No copy constructor:
  Boat				(const Boat&);

  //  No copy assignment op:
  Boat&	operator=		(const Boat&);

protected :
  //  III.  Protected methods:

public :
  //  IV.  Constructor(s), assignment op(s), factory(s) and destructor:
  //  PURPOSE:  To initialize '*this' to an empty list with name 'newNameCPtr'.
  //	No return value.
  Boat				(const char*	newNameCPtr
				) :
				nameCPtr_(newNameCPtr),
				preBoarderPtr_(NULL)
				{
				  //  INITIALIZE YOUR MEMBER VARS HERE
				  first=NULL;
                                  least=NULL;
                                  listlength=0;
				}

  //  PURPOSE:  To release the resources of '*this'.  No parameters.
  //	No return value.
  ~Boat			()
  {
    Customer*	run;
    Customer*	next;

    printf("%s's boat returns after a successful day of whale-watching.\n" "Satisfied customers include:\n", getNameCPtr());

  //  DELETE() THE Customer INSTANCES HERE
   run=first;
   while(run!=NULL)
   {
     run->printDepartingMsg();
     next= run->getNextPtr();
     delete(run);
     run= next;
   }

  }

  //  V.  Accessors:
  //  PURPOSE:  To return the number of customers.  No parameters.
  int		getNumCustomers	()
				const
				{return(listlength); } // CHANGE THAT 0

  //  PURPOSE:  To return the C-string telling the name.  No parameters.
  const char*	getNameCPtr()
				const
				 {return(nameCPtr_); }

  //  PURPOSE:  To return 'true' if '*this' boat is waiting for a customer
  //	to pre-board, or 'false' otherwise.  No parameters.
  bool		isWaitingForCustomer()
				const
				{ return(preBoarderPtr_ == NULL); }

  //  VI.  Mutators:
  //  PURPOSE:  To note that customer '*customerPtr' has pre-boarded.
  void		preBoard	(Customer*	customerPtr)
				{
				  printf("%s steps onto %s's boat.\n",customerPtr->getNameCPtr(),getNameCPtr());
				  preBoarderPtr_	= customerPtr;
				}

  //  PURPOSE:  To return the address of the pre-boarded customer so they
  //	can leave this board and go to the next.  Returns disembarking customer
  //	ptr.  No parameters.
  Customer*	disembark	()
  				{
				  Customer* toReturn	= preBoarderPtr_;

				  preBoarderPtr_	= NULL;
				  printf("%s leaves %s's boat.\n",toReturn->getNameCPtr(),getNameCPtr());
				  return(toReturn);
				}

  //  VII.  Methods that do the main and misc. work of class:
  //  
  void		board		()
  {
    //  YOUR CODE HERE
    if(preBoarderPtr_==NULL)
    {
      first=preBoarderPtr_;
      least=preBoarderPtr_;
    }
    else
    {

      least->setNextPtr(preBoarderPtr_);
      least=least->getNextPtr();
     }
    listlength++;
    preBoarderPtr_	= NULL;
  }


  //  PURPOSE:  To print the names of the customers on '*this' Boat.
  //	No parameters.  No return value.
  void		print		()
  {
    const Customer*  run;

    //  YOUR CODE HERE
    run=first;
    while(run!=NULL)
    {
      printf("%s\n",run->getNameCPtr());
      run= run->getNextPtr();
    }
  }
};


//  PURPOSE:  To ensure that only one Customer at a time goes from the dock
//	to a Boat, or between Boat instances.
pthread_mutex_t			boardingLock;

//  PURPOSE:  To the thread for Boat instance boatPtrArray[i] is waiting
//	for a Customer instance (isWaitingForCustomer() returns true),
// 	then that thread is waiting to be signalled on condArray[i].
pthread_cond_t			condArray[NUM_BOATS];

//  PURPOSE:  This is what the thread for the dock is waiting for to be
//	told when the next Customer instance may safely embark.
//	If the dock thread does not wait then more than one Customer
//	instance might move simultaneously.  And then one of these
//	land-lubbers will fall into the sea!
pthread_cond_t	dockCond;

//  PURPOSE:  To hold pointers to the Boat instances.
Boat*		boatPtrArray[NUM_BOATS];


//  PURPOSE:  To return true if the Boat at index boatIndex needs another
//	Customer before it goes whale-watching, or returns false.
bool		doesNeedCustomers(int		boatIndex)
{
  return( (boatIndex < NUM_BOATS)&&(boatPtrArray[boatIndex]->getNumCustomers() < NUM_CUSTOMERS_PER_BOAT));
}


//  PURPOSE: To This function is run by the threads that implement the Boat
//	instances.
void*		boardCustomers	(void*		vPtr
				)
{
  int		customerId	=*reinterpret_cast<int*>(vPtr); // CHANGE THAT 0!  GET THE INTEGER cPtr POINTS TO
  int		nextCustomerId	= customerId + 1;
  Boat*		thisBoatPtr	= boatPtrArray[customerId];
  Boat*		nextBoatPtr	= boatPtrArray[nextCustomerId];

  printf("%s's boat is ready.\n",thisBoatPtr->getNameCPtr());

  while  (thisBoatPtr->getNumCustomers() < NUM_CUSTOMERS_PER_BOAT)
  {
    //  YOUR CODE HERE
    pthread_mutex_lock(&boardingLock);
    while(thisBoatPtr->isWaitingForCustomer())
    {
    pthread_cond_wait(&condArray[customerId], &boardingLock);
    }

    sleep(1);

    if  (doesNeedCustomers(nextCustomerId) )
    {
      //  YOUR CODE HERE
      Customer* c = thisBoatPtr->disembark();
      nextBoatPtr->preBoard(c);
      pthread_cond_signal(&condArray[nextCustomerId] );
    }
    else

    {
      //  YOUR CODE HERE
      thisBoatPtr->board();       
      pthread_cond_signal(&dockCond);
    }

    //  YOUR CODE HERE
    pthread_mutex_unlock(&boardingLock);
  }

  printf("%s's boat goes whale-watching with:\n",thisBoatPtr->getNameCPtr());
  thisBoatPtr->print();
  
  return(NULL);
}


//  PURPOSE:  To This is what the thread for the dock is waiting for to be
//	told when the next Customer instance may safely embark.
//	If the dock thread does not wait then more than one Customer
//	instance might move simultaneously.  And then one of these
//	land-lubbers will fall into the sea!
void*		embarkBoats	(void*		vPtr
				)
{
  printf("%d customers are waiting at the dock:\n",NUM_CUSTOMERS);

  for  (int i = 0;  i < NUM_CUSTOMERS;  i++)
  {
    //  YOUR CODE HERE
    pthread_mutex_lock(&boardingLock);
    pthread_cond_wait(&dockCond, &boardingLock);
    boatPtrArray[0]->preBoard(new Customer(CUSTOMER_NAME_CPTR_ARRAY[i]));
    //  YOUR CODE HERE
    pthread_cond_signal(&condArray[0]);
    pthread_mutex_unlock(&boardingLock);
  }

  return(NULL);
}


int		main		()
{
  srand(getpid());
  //  YOUR CODE HERE
 pthread_mutex_init(&boardingLock,NULL);
 pthread_cond_init(&dockCond,NULL);
 for( int j=0; j<NUM_BOATS; j++)
{

   pthread_cond_init(&condArray[j],0);
}

  for  (int i = 0;  i < NUM_BOATS;  i++)
  {
    boatPtrArray[i]	= new Boat(SKIPPER_NAME_CPTR_ARRAY[i]);
  }

  pthread_t	boatThreadArray[NUM_BOATS];
  pthread_t	dockThread;
  int		index[NUM_BOATS];

  for  (int i = 0;  i < NUM_BOATS;  i++)
  {
    index[i]	= i;
    //  YOUR CODE HERE
    pthread_create(&boatThreadArray[i],NULL,boardCustomers,(void *)&index[i]);
  }

  //  YOUR CODE HERE
  pthread_create(&dockThread, NULL, embarkBoats,NULL);

  sleep(1);
  pthread_cond_signal(&dockCond);

  for  (int i = 0;  i < NUM_BOATS;  i++)
  {
    //  YOUR CODE HERE
    pthread_join(boatThreadArray[i],(void**)&index[i]);

  }

  //  YOUR CODE HERE
  pthread_join(dockThread,NULL);

  for  (int i = 0;  i < NUM_BOATS;  i++)
  {
    delete(boatPtrArray[i]);
  }

  //  YOUR CODE HERE
  pthread_mutex_destroy(&boardingLock);
  pthread_cond_destroy(&dockCond);
for( int k=0 ; k<NUM_BOATS;k++)
{
  pthread_cond_destroy(&condArray[k]);
}

  return(EXIT_SUCCESS);
}
  
