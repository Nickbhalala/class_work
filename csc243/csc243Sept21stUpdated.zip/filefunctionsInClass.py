def sample1(filename):
    'this is a first file function'
    #filename = input("Enter file name: ")
    inf = open(filename, 'r')
    contents = inf.read()
    inf.close()
    print(contents)
    return contents

def sample2(filename):
    #filename = input("Enter file name: ")
    infile = open(filename, 'r')
    l = infile.readlines()
    infile.close()
    print(l)
##    for line in l:
##        print(line, end = "")
    return l

def sample3():
    filename = input("Enter file name: ")
    infile = open(filename, 'r')
    # This only considers <= 3 lines
    print(infile.readline(),end="")
    print(infile.readline(),end="")
    print(infile.readline(),end="")
    infile.close()

def sample4():
    filename = input("Enter file name: ")
    infile = open(filename, 'r')
    print(infile.readline(), end="")
    print(infile.read(),end="")
    infile.close() 

