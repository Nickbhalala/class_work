def hasConsDups(s):
    'return True if s has consecutive duplicate characters, False otherwise'
    s = s.lower()
    for i in range(1, len(s)):
        if s[i] == s[i-1]:
            return True
    return False

def issorted(lst):
    'return True if lst is sorted and False otherwise'
    for i in range(1, len(lst)):
        if lst[i] < lst[i-1]:
            return False
    return True
        
def getAllLarger(fname, num):
    'return all numbers in fname larger than num or an empty list if none'
    infile = open(fname, 'r')
    s = infile.read()
    infile.close()
    nlst = s.split()
    llst = []
    for val in nlst:
        val = eval(val)
        if val > num:
            llst.append(val)
    return llst

def getLarger(fname, num):
    'return the first number in fname larger than num or num if none are found'
    infile = open(fname, 'r')
    s = infile.read()
    infile.close()
    nlst = s.split()
    #print(nlst)
    #return nlst
    for val in nlst:
        val = eval(val)
        if val > num:
            return val
    return num
    
def numChars(fname):
    'return the number of characters in the file fname'
    inf = open(fname, 'r')
    s = inf.read()
    #lst = inf.readlines()
    inf.close()
    return len(s)
##    count = 0
##    for line in lst:
##        count += len(line)
##    return count
    
def numLines(fname):
    'return the number of lines in the file fname'
    inf = open(fname, 'r')
    lst = inf.readlines()
    #s = inf.read()
    inf.close()
##    lst = s.split('\n')
##    print(lst)
    return len(lst)
##    count = 0
##    for line in lst:
##        count += 1
##    return count
    
# bmi(100, 64) -> 'underweight'
# bmi(130, 64) -> 'optimal'
# bmi(155, 64) -> 'overweight'
def bmi(wt, ht):
    'compute and return a string for the bmi of a person (wt in lbs and ht in inches)'
    val = wt * 703 / ht ** 2
    #print(val)
    if val < 19:
        return 'underweight'
    elif val < 25: # val >= 19
        return 'optimal'
    else: # val >= 25
        return 'overweight'

def login():
    'enter a login id and print a message about it'
    users = ['emily', 'nick', 'mark', 'julie']
    name = input("Enter a login id (all lowercase letters): ")
    if name in users:
        print("You're in!")
    else:
        print("User unknown.")
    print("Done")

def revStr():
    'get a 3-character string from the user and return it in reverse'
    word = input("Enter a three-character string: ")
    if len(word) == 3:
        newStr = word[2] + word[1] + word[0]
        return newStr
    else:
        return "Invalid"
        
def reverse():
    'get a 3-character string from the user and print it in reverse'
    word = input("Enter a three-character string: ")
    if len(word) == 3:
        #print(word[::-1])
        print(word[2], word[1], word[0], sep = "")
    else:
        print("Invalid")

def guess():
    'check if a name entered by the user is a special secret name'
    secret = "annika"
    name = input("Enter a name: ").lower()
    if name == secret: 
        print("You got it!")
    print("Done")
