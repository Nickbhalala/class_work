from BankAccountStartInClass import Account

class Savings(Account):
    'a savings account'
    
    def setRate(self, value):
        'set the yearly interest rate'
        self.rate = value

    def addInterest(self):
        'add one month of interest to the balance'
        self.balance += self.balance*(self.rate/12)
        
    def get(self):
        'prints the value of the balance'
        print(f'balance = ${self.balance:.2f}\nrate = {self.rate}%')
