class Animal(object):
    'an abstraction of an animal'

    def __init__(self, st = 'tiger', language = 'growl'):
        'the constructor'
        self.species = st
        self.lang = language

    def setSpecies(self, st):
        'set the species of the animal'
        self.species = st

    def setLanguage(self, language):
        'set the language of the animal'
        self.lang = language

    def speak(self):
        'make the animal speak'
        if self.lang == '':
            return f"I am a {self.species}"
        else:
            return f"I am a {self.species} and I {self.lang}"

    def __repr__(self):
        'the representation of the animal'
        return f"Animal({self.species}, {self.lang})"

    def __str__(self):
        'the string representation of the animal'
        #return self.speak()
        return Animal.speak(self)
        
class Bird(Animal):
    'an abstraction of a bird'

    def __init__(self, lang = 'chirp'):
        'the constructor'
        Animal.__init__(self, 'bird', lang)

    def __repr__(self):
        'the representation of a Bird'
        return f"Bird({self.lang})"

    def fly(self, n):
        'make the bird fly'
        return f"I am flying {n} feet"
    
    
