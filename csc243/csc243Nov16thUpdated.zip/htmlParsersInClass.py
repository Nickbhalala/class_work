from html.parser import HTMLParser
from urllib.request import urlopen
from urllib.parse import urljoin

def testParser(url):
    content = urlopen(url).read().decode()
    parser = Collector(url)
    parser.feed(content)
    return parser.getData()

# Collect the links into a list
class Collector(HTMLParser):
    'the final parser for the web crawler'

    def __init__(self, url):
        HTMLParser.__init__(self)
        self.lst = []
        self.url = url

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            for pair in attrs:
                if pair[0].lower() == 'href':
                    #if "mailto" not in pair[1]:
                    if not pair[1].lower().startswith('mailto:'):
                        self.lst.append(urljoin(self.url, pair[1]))

    def getData(self):
        return self.lst

# 1. URLs can be relative
# 3. Gather these into a list rather than printing
class LinksPrinter(HTMLParser):
    'print the links in an HTML page'
    
    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            for pair in attrs:
                if pair[0].lower() == 'href':
                    #if "mailto" not in pair[1]:
                    if not pair[1].lower().startswith('mailto:'):
                        print(pair[1])

class ListParser(HTMLParser):
    'gather the items in a list'

    def __init__(self):
        HTMLParser.__init__(self)
        self.ilst = []
        self.inL = False

    def handle_data(self, data):
        if self.inL:
            self.ilst.append(data.strip())

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'li':
            self.inL = True

    def handle_endtag(self, tag):
        if tag.lower() == 'li':
            self.inL = False

    def getItems(self):
        return self.ilst

class HeaderParser(HTMLParser):
    'gather a list of heading data'

    def __init__(self):
        HTMLParser.__init__(self)
        self.hlst = []
        self.inH = False # not in heading

    def handle_data(self, data):
        if self.inH:
            self.hlst.append(data.strip())

    def handle_starttag(self, tag, attrs):
        'mark that we are inside a header'
        if tag.lower() in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self.inH = True # entering a heading

    def handle_endtag(self, tag):
        'mark that we are leaving a header'
        if tag.lower() in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self.inH = False # leaving a heading

    def getHeadings(self):
        return self.hlst

class DataCollector(HTMLParser):
    'collect and return the data in an HTML page'

    def __init__(self):
        'the constructor'
        # call the parent constructor
        # create an empty string to store the data
        HTMLParser.__init__(self)
        self.st = ''

    def handle_data(self, data):
        'put data into a string'
        # put the data into the string we're building
        self.st += data.strip() + " "

    def getData(self):
        'return the string built by the parser'
        # return the string we built
        return self.st

class DataPrinter(HTMLParser):
    'print the data in an HTML page'

    def handle_data(self, data):
        'print the data in the page'
        print(data)

class PrettyParser(HTMLParser):
    'a parser that prints starting and ending tags with indentation'

    def __init__(self):
        'the constructor'
        HTMLParser.__init__(self) # call the parent constructor
        self.indent = 0

    # print the tag -> use the indent
    # increase the indentation
    def handle_starttag(self, tag, attrs):
        'handle starting tags'
        print(f"{' ' * self.indent}start {tag}")
        if tag.lower() not in ['br', 'img']: # not a general solution
            self.indent += 4

    # print the tag -> use the indent
    # decrease the indentation
    def handle_endtag(self, tag):
        'handle ending tags'
        self.indent -= 4
        print(f"{' ' * self.indent}end {tag}")

class MyHTMLParser(HTMLParser):
    def handle_starttag(self, tag, attrs):
        print(f"Encountered a {tag} start tag with attrs {attrs}")
    def handle_endtag(self, tag):
        print(f"Encountered a {tag} end tag")


