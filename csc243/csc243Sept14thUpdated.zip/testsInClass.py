def test0(n):
    if n < 0:
        print("n is negative")
        print("These indented statements are part")
        print("of the if statement body")
        print("Still in the body...")
    print("In the body no more")
    print("I am executed whether or not the condition")
    print("evaluates to True.")

def test1(n):
    if n < 0:
        print("n is negative")
    else:
        print("n is not negative")

def test2(n):
    if n < 0:
        print("n is negative")
        print("n is still negative")
    else:
        print("n is not negative")
        print("n is still not negative")
    print("n is anything here...")

def test3(n):
    if n < 0:
        print("n is negative")
    elif n > 0:
        print("n is positive")
    else:
        print("n is 0")

def temp2(t):
    if t >= 86:
        print("It is hot")
    elif t > 0:
        print("It is cool")
    else:
        print("It is freezing")

def temp3(t):
    if t > 0 and t < 86:
        print("It is cool")
    elif t >= 86:
        print("It is hot")
    else:
        print("It is freezing")
