def printNums(s):
    'print numbers based on s'
    # if s is 'even', call evenNums
    # if s is 'odd', call oddNums
    if s == 'odd':
        oddNums()
    elif s == 'even':
        evenNums()

def oddNums():
    'input a number from the user and print the odd numbers'
    num = int(input("Enter a number: "))
    for i in range(1, num+1, 2):
        print(i, end = " ")
    print()

def evenNums():
    'input a number from the user and print the even numbers up to that number'
    num = int(input("Enter a number: "))
    for n in range(2, num+1, 2):
        print(n, end = " ")
    print()

def sequences():
    'print a bunch of sequences'
    for i in range(0, 1):
        print(i, end = " ")
    print()
    for i in range(0, 5):
        print(i, end = " ")
    print()
    for i in range(1, 5):
        print(i, end = " ")
    print()
    for i in range(3, 7):
        print(i, end = " ")
    print()
    for i in range(1, 2):
        print(i, end = " ")
    print()
    for i in range(0, 4, 3):
        print(i, end = " ")
    print()
    for num in range(0, 19, 2):
        print(num, end = " ")
    print()
    for num in range(17, 4, -4):
        print(num, end = " ")
    print()

def enterVal():
    value = input("Enter a value: ")
    print("value is ", value)

def getNum():
    num = eval(input("Enter a number: "))
    #num = float(input("Enter a number: "))
    return num

def printName(name):
    'print a name in a weird way'
    for c in name:
        print(c, end = " ")
##    for index in range(len(name)):
##        print(name[index], end = " ")
    print()
    for i in range(len(name)):
        print("Yes!")

